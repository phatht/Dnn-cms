﻿Namespace Ventrian.NewsArticles.Import

    Public Enum FeedExpiryType

        None = -1
        Minute = 0
        Hour = 1
        Day = 2
        Month = 3
        Year = 4

    End Enum

End Namespace
