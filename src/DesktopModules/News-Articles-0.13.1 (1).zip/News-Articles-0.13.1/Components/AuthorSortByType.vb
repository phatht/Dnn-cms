﻿'
' News Articles for DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2007
' by Ventrian ( sales@ventrian.com ) ( http://www.ventrian.com )
'

Namespace Ventrian.NewsArticles

    Public Enum AuthorSortByType

        ArticleCount
        DisplayName
        FirstName
        LastName
        UserName

    End Enum

End Namespace
