﻿Namespace Ventrian.NewsArticles

    Public Enum WatermarkPosition

        TopLeft
        TopRight
        BottomLeft
        BottomRight

    End Enum

End Namespace


