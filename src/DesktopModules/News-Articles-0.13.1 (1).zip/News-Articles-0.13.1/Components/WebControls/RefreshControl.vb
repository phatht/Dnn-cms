﻿
Namespace Ventrian.NewsArticles.Components.WebControls

    Public Class RefreshControl
        Inherits System.Web.UI.WebControls.LinkButton

    End Class

End Namespace
