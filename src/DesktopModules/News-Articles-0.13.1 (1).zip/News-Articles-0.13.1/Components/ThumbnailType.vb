﻿'
' News Articles for DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2011
' by Ventrian ( sales@ventrian.com ) ( http://www.ventrian.com )
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace Ventrian.NewsArticles

    Public Enum ThumbnailType

        Proportion
        Square

    End Enum

End Namespace
