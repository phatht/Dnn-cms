﻿Namespace Ventrian.NewsArticles.API.MetaWebLog

    Friend Class MetaBlogInfo

        Public BlogId As String
        Public BlogName As String
        Public Url As String

    End Class

End Namespace
