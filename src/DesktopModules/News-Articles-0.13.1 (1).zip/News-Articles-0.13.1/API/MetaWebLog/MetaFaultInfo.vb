﻿Namespace Ventrian.NewsArticles.API.MetaWebLog

    Public Class MetaFaultInfo

        Public FaultCode As String
        Public FaultString As String

    End Class

End Namespace
