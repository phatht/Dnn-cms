﻿Namespace Ventrian.NewsArticles.API.MetaWebLog

    Friend Structure MetaMediaInfo

#Region "Properties"

        Public Bits As Byte()
        Public Name As String
        Public Type As String

#End Region

    End Structure

End Namespace
