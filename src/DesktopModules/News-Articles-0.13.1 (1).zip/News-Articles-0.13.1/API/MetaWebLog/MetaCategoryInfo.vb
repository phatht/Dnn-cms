﻿Namespace Ventrian.NewsArticles.API.MetaWebLog

    Friend Class MetaCategoryInfo

        Public Description As String
        Public HtmlUrl As String
        Public Id As String
        Public RssUrl As String
        Public Title As String

    End Class

End Namespace
