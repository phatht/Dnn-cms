﻿Namespace Ventrian.NewsArticles.API.MetaWebLog

    Friend Structure MetaMediaUrlInfo

#Region "Constants and Fields"

        Public Url As String

#End Region

    End Structure

End Namespace
